class AuthenticationBase(object):
    def authorized(self):
        return False
